/* 
BSL Shaders v10 Series by Capt Tatsu 
https://capttatsu.com 
*/ 

#version 120 

#extension GL_ARB_shader_texture_lod : enable

#define NETHER
#define FSH

#include "/program/clrwl_gbuffers.glsl"
